//
//  KWKApp.swift
//  KWK
//
//  Created by user on 23.6.23.
//

import SwiftUI

@main
struct KWKApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
